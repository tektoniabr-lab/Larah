/*
 * ThreadsLogo (phosphor-icons/ThreadsLogo@0.0.57)
 *
 * Learn More: https://www.framer.com/asset-urls
 */

export * from "https://framerusercontent.com/modules/16LZsF1GYIA3bRGv27wF/1SPrR0fuXC6H7qoU6DG1/ThreadsLogo.js"
export { default } from "https://framerusercontent.com/modules/16LZsF1GYIA3bRGv27wF/1SPrR0fuXC6H7qoU6DG1/ThreadsLogo.js"
