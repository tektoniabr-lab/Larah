/*
 * YoutubeLogo (phosphor-icons/YoutubeLogo@0.0.57)
 *
 * Learn More: https://www.framer.com/asset-urls
 */

export * from "https://framerusercontent.com/modules/9n1m4SYYjOmzvdghRTnQ/LqhPBKDoecG2DoqtIyVc/YoutubeLogo.js"
export { default } from "https://framerusercontent.com/modules/9n1m4SYYjOmzvdghRTnQ/LqhPBKDoecG2DoqtIyVc/YoutubeLogo.js"
